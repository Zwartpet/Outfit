Advanced Card Systems Ltd.



Contents
----------------

   1. Release notes
   2. History
   3. File Content
   4. Limitations



1. Release notes
----------------

Version: 1.0.2.0
Release date: 21-Nov-2007 



2. Installer Set-up History
----------------

1.0.0.0		New Release
1.0.1.0		UI modification (12/10/2005)
                Updated library
1.0.2.0		Added Vista support



3. File Content
----------------

acr120.cat	x.x.x.x	
acr120.inf	x.x.x.x
acr120.sys	1.0.1.0
acr120x64.sys	1.0.1.0
ACR120U.dll	1.5.1.2
ACR120Ux64.dll	1.5.1.2

Utilities
x64 --> difxapi.dll	2.0.1.0
x86 --> difxapi.dll	2.1.0.0
	

4. Limitations
----------------

1) The installer cannot be called by another .exe (calling program). If you really need to do so, the .exe (calling program) must be in the same directory with setup.exe.

2) After each uninstallation, the user must reboot before another installation.

3) Does not support Windows NT installation.

4) Added Windows Vista support (32-bit and 64-bit platforms)



5. Support
----------------

In case of problem, please contact ACS through:

web site: http://www.acs.com.hk/
email: info@acs.com.hk




-----------------------------------------------------------------


Copyright 
Copyright by Advanced Card Systems Ltd. (ACS) No part of this reference manual may be reproduced or transmitted in any from without the expressed, written permission of ACS. 

Notice 
Due to rapid change in technology, some of specifications mentioned in this publication are subject to change without notice. Information furnished is believed to be accurate and reliable. ACS assumes no responsibility for any errors or omissions, which may appear in this document. 



















